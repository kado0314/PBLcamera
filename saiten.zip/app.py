import base64
import json
import cv2
import numpy as np
from flask import Flask, request, render_template_string
from werkzeug.utils import secure_filename
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))
# 🌟 修正後 🌟
from scorer_main import FashionScorer 

# --- 設定 ---
app = Flask(__name__)
# AI採点クラスをインスタンス化
# ここでは一旦、性別などをニュートラルとして初期化
scorer = FashionScorer(user_gender="neutral", user_locale="ja-JP")

# テンプレートとして使用するHTML
FASHION_SCORE_HTML = """
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>ファッション採点アプリ</title>
</head>
<body>
    <h1>ファッション採点アプリ</h1>
   <form id="fashion_score_form" method="POST" enctype="multipart/form-data">
        <label for="image_input">画像をアップロードまたはカメラで撮影:</label><br>
        <input type="file" id="image_input" name="image_file" accept="image/*" capture="camera"><br><br>
        
        <input type="hidden" name="user_gender" value="neutral">
        <input type="hidden" name="intended_scene" value="everyday">
        
        <button type="submit">採点する</button>
    </form>
    
    <p style="margin-top: 20px;">または</p>
<div style="border: 1px solid #ddd; padding: 10px; margin-bottom: 20px;">
    <h3>📷 リアルタイムチェック</h3>
    <video id="webcam_video" width="320" height="240" autoplay style="border: 1px solid #000;"></video>
    <button type="button" id="capture_button">カメラで撮影して採点</button>
    <canvas id="hidden_canvas" style="display:none;"></canvas>
    <input type="hidden" id="captured_image_data" name="captured_image_data">
</div>

<script>
    const video = document.getElementById('webcam_video');
    const canvas = document.getElementById('hidden_canvas');
    const captureButton = document.getElementById('capture_button');
    const capturedImageData = document.getElementById('captured_image_data');
    const form = document.getElementById('fashion_score_form');

    // 1. カメラの起動
    captureButton.disabled = true;
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } })
            .then(function(stream) {
                video.srcObject = stream;
                video.play();
                captureButton.disabled = false;
            })
            .catch(function(err) {
                console.error("カメラアクセスエラー: ", err);
                captureButton.textContent = "カメラアクセスを許可してください";
            });
    }

    // 2. 撮影ボタンの処理
    captureButton.addEventListener('click', function() {
        // カメラ映像を非表示のCanvasに描画
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas.getContext('2d').drawImage(video, 0, 0, video.videoWidth, video.videoHeight);

        // Canvasの内容をJPEG Base64データURIに変換
        const imageDataURL = canvas.toDataURL('image/jpeg', 0.9); 
        
        // Base64データを隠しフィールドに格納
        capturedImageData.value = imageDataURL.split(',')[1]; 

        // フォームに Base64 データ送信モードであることを伝えるフラグ
        const modeInput = document.createElement('input');
        modeInput.type = 'hidden';
        modeInput.name = 'submit_mode';
        modeInput.value = 'camera_base64';
        form.appendChild(modeInput);
        
        // ファイルアップロードフィールドを無効化
        document.getElementById('image_input').disabled = true;

        // フォームを送信
        form.submit();
    });
</script>
    
    {% if uploaded_image_data %}
        <hr>
        <h3>📸 採点対象の画像</h3>
        <img src="{{ uploaded_image_data }}" style="max-width: 300px; height: auto; border: 1px solid #ccc;">
        <hr>
    {% endif %}

    {% if score is not none %}
        <hr>
        <h2>--- 採点結果 ---</h2>
        <p>あなたの今日のファッションは **{{ score }} 点**です！</p>
        <p>フィードバック: 
            <ul>
                {% for exp in feedback[:3] %}
                    <li>{{ exp }}</li>
                {% endfor %}
            </ul>
        </p>
        
        <h3>✨ おすすめ情報</h3>
        <p>{{ recommendation }}</p>

        {% if subscores %}
        <h4>サブスコア詳細 (最大100点)</h4>
        <ul>
            {% set labels = {
                'color_harmony': '色の調和',
                'fit_and_silhouette': 'サイズ感・シルエット',
                'item_coordination': 'アイテムの組合せ',
                'cleanliness_material': '清潔感・素材感',
                'accessories_balance': 'アクセサリーのバランス',
                'trendness': 'トレンド性',
                'tpo_suitability': 'TPO適合',
                'photogenic_quality': '写真映え'
            } %}
            {% for key, value in subscores.items() %}
                <li>{{ labels[key] }}: {{ value }} 点</li>
            {% endfor %}
        </ul>
        {% endif %}

    {% endif %}
</body>
</html>
"""

@app.route('/', methods=['GET', 'POST'])
def fashion_score_app():
    """
    GET: 採点フォームを表示
    POST: 画像を受け取り、AIで採点し、結果を表示
    """
    score = None
    feedback = []
    recommendation = "採点後に具体的なアドバイスが表示されます。"
    subscores = None
    

    uploaded_image_data = None # 初期化を忘れないように

    if request.method == 'POST':
        # フォームから送信モードを取得（カメラかファイルアップロードか）
        submit_mode = request.form.get('submit_mode')
        
        # 処理対象の画像データとBase64文字列を初期化
        image_base64_string = None
        
        if submit_mode == 'camera_base64':
            # 🌟 カメラ撮影データの場合 🌟
            image_base64_string = request.form.get('captured_image_data')
            
            if not image_base64_string:
                feedback.append("カメラ画像データが見つかりませんでした。")
                
        else:
            # 🌟 通常のファイルアップロードの場合 🌟
            if 'image_file' in request.files:
                file = request.files['image_file']
                
                if file.filename != '':
                    try:
                        img_bytes = file.read()
                        nparr = np.frombuffer(img_bytes, np.uint8)
                        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

                        if img is None:
                            raise ValueError("画像ファイルのデコードに失敗しました。")

                        # Base64文字列を作成
                        _, buffer = cv2.imencode(".jpg", img)
                        image_base64_string = base64.b64encode(buffer).decode('utf-8')

                    except Exception as e:
                        score = None
                        feedback = [f"画像処理エラー: {str(e)}"]

        
        # 採点処理（カメラ/ファイル共通）
        if image_base64_string:
            try:
                # 画像表示用データURIを作成
                uploaded_image_data = f"data:image/jpeg;base64,{image_base64_string}"

                # 2. メタデータの設定 (共通)
                metadata = {
                    "user_locale": "ja-JP",
                    "user_gender": request.form.get("user_gender", "neutral"),
                    "intended_scene": request.form.get("intended_scene", "everyday")
                }
                
                # 3. AI採点モジュールの実行
                result = scorer.analyze(image_base64_string, metadata)
                
                # 4. 結果の変数への格納
                score = result.get("overall_score")
                subscores = result.get("subscores")
                feedback = result.get("explanations", [])
                
                # warningsをレコメンデーションとして利用 (既存ロジック)
                warnings = result.get("warnings", [])
                if warnings:
                    recommendation = warnings[0] + " 他の角度で撮ると改善する可能性があります。"
                else:
                    recommendation = "特に大きな問題は見つかりませんでした。次は色違いに挑戦してみてはいかがでしょう。"
                    
            except Exception as e:
                score = None
                feedback = [f"AI採点エラーが発生しました: {str(e)}"]
                recommendation = "採点中に予期せぬエラーが発生しました。"

    # HTMLテンプレートに変数を与えてレンダリング
    # HTMLテンプレートに変数を与えてレンダリング
    return render_template_string(
        FASHION_SCORE_HTML, 
        score=score, 
        feedback=feedback, 
        recommendation=recommendation,
        subscores=subscores,
        uploaded_image_data=uploaded_image_data # これが必須！
    )

if __name__ == '__main__':
    print("ファッション採点アプリを起動中: http://127.0.0.1:5000/")
    app.run(debug=True)